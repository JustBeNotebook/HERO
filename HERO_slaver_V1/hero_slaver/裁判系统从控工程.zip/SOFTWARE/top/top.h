#ifndef RM__TOP__H
#define RM__TOP__H

#include "sys.h"


float my_cos(int angel);
//
float my_sin(int angel);





#endif
